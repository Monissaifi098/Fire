from .start import router as start_router
from .orders import router as orders_router
from .payments import router as payments_router
from .support import router as support_router
from .admin import router as admin_router

__all__ = ["start_router", "orders_router", "payments_router", "support_router", "admin_router"]
